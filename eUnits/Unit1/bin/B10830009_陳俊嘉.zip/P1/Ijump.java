package P1;

public interface Ijump {
	public abstract void jump_go();
}
