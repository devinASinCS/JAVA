package P1;

public interface Irun {
	public abstract void run_go();
}
