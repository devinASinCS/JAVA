package P1;

public interface Ifly {
	public abstract void fly_go();
}
