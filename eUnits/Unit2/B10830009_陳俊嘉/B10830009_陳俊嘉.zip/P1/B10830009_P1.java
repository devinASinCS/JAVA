package P1;

import javax.swing.JFrame;

public class B10830009_P1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame = new JFrame("B10830009_P1");
		frame.setSize(1220, 640);
		frame.setLocation(30, 25);
		frame.setContentPane(new Panel());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}
