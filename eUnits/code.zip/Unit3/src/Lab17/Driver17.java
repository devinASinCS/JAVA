package Lab17;

import javax.swing.JFrame;

public class Driver17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame = new JFrame();
		frame.setSize(450, 500);
		frame.setLocation(200,200);
		frame.setContentPane(new Panel17());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}
